package my.edu.tarc.finalyearproject.Interface;

import java.util.logging.Filter;

public interface FilterListFragmentListener {
    void onFilterSelected(Filter filter);
}
