package my.edu.tarc.finalyearproject.Utils;

/**
 * Created by delaroy on 4/1/18.
 */

public class Constants {
    public static String KEY_EMAIL = "email";
    public static String KEY_PASSWORD = "password";
}
