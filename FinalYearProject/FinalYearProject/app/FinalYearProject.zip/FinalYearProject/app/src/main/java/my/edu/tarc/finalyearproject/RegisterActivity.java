package my.edu.tarc.finalyearproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    Button Register;
    EditText Email, Address,Password,Name;
     FirebaseAuth mFireBaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);

        Register = (Button) findViewById(R.id.Register);
        Email = (EditText) findViewById(R.id.Email);
        Address = (EditText) findViewById(R.id.Address);
        Password = (EditText) findViewById(R.id.Password);
        Name = (EditText)findViewById (R.id.Name);

        Register.setOnClickListener(this);
        mFireBaseAuth = FirebaseAuth.getInstance();


    }


    @Override
    public void onClick(View v) {
        String email  = Email.getText().toString().trim();
        String pwd    = Password.getText().toString().trim();

        if(email.isEmpty()){
            Email.setError("Please enter the email");
            Email.requestFocus();

        }
        else if (pwd.isEmpty()){
            Password.setError("Please enter the password");
            Password.requestFocus();
        }

    else if (!(email.isEmpty() && pwd.isEmpty())){
            mFireBaseAuth.createUserWithEmailAndPassword(email,pwd).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(!task.isSuccessful()){
                        Toast.makeText(RegisterActivity.this,"Sign Up Unsuccessful", Toast.LENGTH_SHORT).show() ;
                    }
                    else {
                        startActivity(new Intent(RegisterActivity.this,MainActivity.class));
                    }
                }
            });

        }

      else {
         Toast.makeText(RegisterActivity.this, "Error", Toast.LENGTH_SHORT).show();


  /*       mFireBaseAuth.createUserWithEmailAndPassword(email, pwd)
                 .addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                         Toast.makeText(RegisterActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
*//*
                                progressBar.setVisibility(View.GONE);
*//*
                         // If sign in fails, display a message to the user. If sign in succeeds
                         // the auth state listener will be notified and logic to handle the
                         // signed in user can be handled in the listener.
                         if (!task.isSuccessful()) {
                             Toast.makeText(RegisterActivity.this, "Authentication failed." + task.getException(),
                                     Toast.LENGTH_SHORT).show();
                         } else {
                             startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                             finish();
                         }
                     }
                 });*/
     }
    }
}
