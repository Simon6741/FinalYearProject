package my.edu.tarc.finalyearproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AccountFragment extends Fragment  {

    Button CallLogin,callRegister;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       return inflater.inflate(R.layout.fragment_account,container,false);

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

/*        CallLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoLogin = new Intent(getActivity(),LoginActivity.class);
                startActivity(GoLogin);

            }
        });
        callRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoRegister = new Intent(getActivity(),RegisterActivity.class);
                startActivity(GoRegister);
            }
        });*/

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        CallLogin = (Button) getView().findViewById(R.id.CallLogin);
        callRegister = (Button) getView().findViewById(R.id.callRegister);
                CallLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoLogin = new Intent(getActivity(),LoginActivity.class);
                startActivity(GoLogin);

            }
        });
        callRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoRegister = new Intent(getActivity(),RegisterActivity.class);
                startActivity(GoRegister);
            }
        });


    }
}

