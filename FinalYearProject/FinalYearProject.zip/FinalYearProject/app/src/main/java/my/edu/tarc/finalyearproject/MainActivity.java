package my.edu.tarc.finalyearproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton VisualizeButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        VisualizeButton = (ImageButton) findViewById(R.id.VisualizeButton);

        VisualizeButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Toast.makeText(MainActivity.this,"It works", Toast.LENGTH_SHORT).show() ;
            }
        });
    }
}
